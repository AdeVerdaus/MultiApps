package com.vinz.latihanrecyclerviewpraktikum.activity.modul6.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.vinz.latihanrecyclerviewpraktikum.R
import com.vinz.latihanrecyclerviewpraktikum.data.remote.practice.Food

// Kelas ini digunakan untuk menampilkan detail makanan
class DetailRetrofitActivity : AppCompatActivity() {
    // Fungsi ini dipanggil saat activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mengatur layout untuk activity ini
        setContentView(R.layout.activity_detail_retrofit)

        // Mendapatkan data makanan dari intent
        val getData = intent.getParcelableExtra<Food>("food")!!

        // Menghubungkan variabel dengan komponen di layout
        val foodName = findViewById<TextView>(R.id.food_name)
        val foodDesc = findViewById<TextView>(R.id.food_description)
        val foodImage = findViewById<ImageView>(R.id.food_image)

        // Mengatur teks untuk nama dan deskripsi makanan
        foodName.text = getData.name
        foodDesc.text = getData.description
        // Menggunakan library Glide untuk memuat gambar dari URL dan menampilkannya di ImageView
        Glide.with(this)
            .load(getData.image)
            .into(foodImage)
    }
}