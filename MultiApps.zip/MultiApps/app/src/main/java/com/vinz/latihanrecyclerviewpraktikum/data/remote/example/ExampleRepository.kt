package com.vinz.latihanrecyclerviewpraktikum.data.remote.example

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExampleRepository {
    // Mendeklarasikan variabel _listPlayer sebagai MutableLiveData yang berisi List dari ExampleAPIResponse
    private val _listPlayer = MutableLiveData<List<ExampleAPIResponse>>()
    // Mendeklarasikan variabel listPlayer sebagai LiveData yang berisi List dari ExampleAPIResponse
    var listPlayer: LiveData<List<ExampleAPIResponse>> = _listPlayer

    // Mendeklarasikan variabel _isLoading sebagai MutableLiveData yang berisi Boolean
    private var _isLoading = MutableLiveData<Boolean>()
    // Mendeklarasikan variabel isLoading sebagai LiveData yang berisi Boolean
    var isLoading: LiveData<Boolean> = _isLoading

    // Mendeklarasikan variabel _player sebagai MutableLiveData yang berisi ExampleAPIResponse
    private val _player = MutableLiveData<ExampleAPIResponse>()
    // Mendeklarasikan variabel player sebagai LiveData yang berisi ExampleAPIResponse
    var player: LiveData<ExampleAPIResponse> = _player

    // Fungsi untuk mendapatkan semua pemain
    fun getAllPlayer() {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = ExampleAPIConfig.getApiService().getAllPlayers()
        // Mengirim request ke API
        service.enqueue(object : Callback<List<ExampleAPIResponse>> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<List<ExampleAPIResponse>>,
                response: Response<List<ExampleAPIResponse>>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _listPlayer dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _listPlayer.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<List<ExampleAPIResponse>>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    // Fungsi untuk mendapatkan detail pemain berdasarkan id
    fun getDetailPlayer(id: String) {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = ExampleAPIConfig.getApiService().getDetailPlayer(id)
        // Mengirim request ke API
        service.enqueue(object : Callback<ExampleAPIResponse> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<ExampleAPIResponse>,
                response: Response<ExampleAPIResponse>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _player dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _player.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<ExampleAPIResponse>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    // Fungsi untuk menambahkan pemain
    fun addPlayer(player: ExampleAPIRequest) {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = ExampleAPIConfig.getApiService().addFootballPlayer(player)
        // Mengirim request ke API
        service.enqueue(object : Callback<ExampleAPIResponse> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<ExampleAPIResponse>,
                response: Response<ExampleAPIResponse>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _player dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _player.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<ExampleAPIResponse>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    // Fungsi untuk memperbarui pemain berdasarkan id
    fun updatePlayer(id: String, player: ExampleAPIRequest) {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = ExampleAPIConfig.getApiService().updateDetailPlayer(id, player)
        // Mengirim request ke API
        service.enqueue(object : Callback<ExampleAPIResponse> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<ExampleAPIResponse>,
                response: Response<ExampleAPIResponse>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _player dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _player.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<ExampleAPIResponse>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    // Fungsi untuk menghapus pemain berdasarkan id
    fun deletePlayer(id: String) {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = ExampleAPIConfig.getApiService().deletePlayer(id)
        // Mengirim request ke API
        service.enqueue(object : Callback<ExampleAPIResponse> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<ExampleAPIResponse>,
                response: Response<ExampleAPIResponse>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _player dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _player.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<ExampleAPIResponse>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    // Objek companion yang digunakan untuk membuat instance dari ExampleRepository
    companion object {
        @Volatile
        private var instance: ExampleRepository? = null
        // Fungsi untuk mendapatkan instance dari ExampleRepository
        fun getInstance(): ExampleRepository =
            instance ?: synchronized(this) {
                instance ?: ExampleRepository()
            }.also { instance = it }
    }
}