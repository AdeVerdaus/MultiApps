package com.vinz.latihanrecyclerviewpraktikum.activity.modul6.example

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.vinz.latihanrecyclerviewpraktikum.R
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleAPIRequest
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleViewModel
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleViewModelFactory

// Kelas ini digunakan untuk menambahkan data pemain baru
class AddDummyAPIActivity : AppCompatActivity() {
    // Mendeklarasikan variabel untuk ViewModel
    private lateinit var exampleViewModel: ExampleViewModel
    // Mendeklarasikan variabel untuk input nama pemain
    private lateinit var playerName: TextInputEditText
    // Mendeklarasikan variabel untuk input deskripsi pemain
    private lateinit var playerDescription: TextInputEditText
    // Mendeklarasikan variabel untuk input gambar pemain
    private lateinit var playerImage: TextInputEditText

    // Fungsi ini dipanggil saat activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_dummy_apiactivity)

        // Membuat instance dari ViewModel
        val factory = ExampleViewModelFactory.getInstance()
        exampleViewModel = ViewModelProvider(this, factory)[ExampleViewModel::class.java]

        // Menghubungkan variabel dengan komponen di layout
        playerName = findViewById(R.id.player_name_edit)
        playerDescription = findViewById(R.id.player_desc_edit)
        playerImage = findViewById(R.id.player_image_edit)

        // Mengatur aksi ketika tombol diklik
        onClick()
    }

    // Fungsi untuk mengatur aksi ketika tombol diklik
    private fun onClick() {
        val btnSavedPlayer = findViewById<MaterialButton>(R.id.saved_player)
        btnSavedPlayer.setOnClickListener {
            // Jika input valid, simpan data
            if (validateInput()) {
                savedData()
            }
        }
    }

    // Fungsi untuk memvalidasi input
    private fun validateInput(): Boolean {
        var error = 0

        // Jika input nama pemain kosong, tambahkan error
        if (playerName.text.toString().isEmpty()) {
            error++
            playerName.error = "Nama pemain tidak boleh kosong"
        }

        // Jika input deskripsi pemain kosong, tambahkan error
        if (playerDescription.text.toString().isEmpty()) {
            error++
            playerDescription.error = "Deskripsi pemain tidak boleh kosong"
        }

        // Jika input gambar pemain kosong, tambahkan error
        if (playerImage.text.toString().isEmpty()) {
            error++
            playerImage.error = "Gambar tidak boleh kosong"
        }

        // Jika tidak ada error, kembalikan true
        return error == 0
    }

    // Fungsi untuk menyimpan data
    private fun savedData() {
        // Membuat objek pemain baru
        val player = ExampleAPIRequest(
            name = playerName.text.toString(),
            avatar = playerImage.text.toString(),
            description = playerDescription.text.toString(),
        )

        // Menambahkan pemain baru ke ViewModel
        exampleViewModel.addPlayer(player)

        // Menampilkan pesan bahwa data berhasil ditambahkan
        Toast.makeText(
            this@AddDummyAPIActivity,
            "Data pemain berhasil ditambahkan",
            Toast.LENGTH_SHORT
        ).show()

        // Mengakhiri activity
        finish()
    }
}