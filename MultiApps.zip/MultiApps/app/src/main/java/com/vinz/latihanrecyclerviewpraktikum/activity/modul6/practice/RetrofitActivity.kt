package com.vinz.latihanrecyclerviewpraktikum.activity.modul6.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.vinz.latihanrecyclerviewpraktikum.R

class RetrofitActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_retrofit)
    }
}