package com.vinz.latihanrecyclerviewpraktikum.data.remote.example

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ExampleAPIService {
    // Fungsi ini digunakan untuk mendapatkan semua pemain sepak bola
    @GET("footballplayer")
    fun getAllPlayers(): Call<List<ExampleAPIResponse>>

    // Fungsi ini digunakan untuk mendapatkan detail pemain sepak bola berdasarkan id
    @GET("footballplayer/{id}")
    fun getDetailPlayer(
        @Path("id") id: String // Parameter id digunakan untuk menentukan pemain sepak bola yang detailnya ingin dilihat
    ): Call<ExampleAPIResponse>

    // Fungsi ini digunakan untuk menambahkan pemain sepak bola baru
    @POST("footballplayer")
    fun addFootballPlayer(
        @Body addRequest: ExampleAPIRequest // Parameter addRequest berisi data pemain sepak bola yang akan ditambahkan
    ): Call<ExampleAPIResponse>

    // Fungsi ini digunakan untuk memperbarui detail pemain sepak bola berdasarkan id
    @PUT("footballplayer/{id}")
    fun updateDetailPlayer(
        @Path("id") id: String, // Parameter id digunakan untuk menentukan pemain sepak bola yang detailnya ingin diperbarui
        @Body updateRequest: ExampleAPIRequest // Parameter updateRequest berisi data pemain sepak bola yang akan diperbarui
    ): Call<ExampleAPIResponse>

    // Fungsi ini digunakan untuk menghapus pemain sepak bola berdasarkan id
    @DELETE("footballplayer/{id}")
    fun deletePlayer(
        @Path("id") id: String, // Parameter id digunakan untuk menentukan pemain sepak bola yang ingin dihapus
    ): Call<ExampleAPIResponse>
}