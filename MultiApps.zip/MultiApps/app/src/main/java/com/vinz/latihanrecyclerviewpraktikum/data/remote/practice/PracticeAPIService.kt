package com.vinz.latihanrecyclerviewpraktikum.data.remote.practice

interface PracticeAPIService {

}